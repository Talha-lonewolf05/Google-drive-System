#pragma once
#include <string>
#include <iostream>

using namespace std;

struct Version_node {
    int version_No;          // Version number
    string content;        // File content for this version
    Version_node* prev;          // Pointer to the previous version
    Version_node* next;          // Pointer to the next version

    Version_node(int versionNumber, const std::string& content)
        : version_No(versionNumber), content(content), prev(nullptr), next(nullptr) {
    }
};
class Doubly_linkedlist {
private:
    Version_node* head;          // Pointer to the first version
    Version_node* tail;          // Pointer to the most recent version
    int version_count;           // Total number of versions
public:
    Doubly_linkedlist() : head(nullptr), tail(nullptr), version_count(0) {}
    ~Doubly_linkedlist() {
        while (head) {
            Version_node* temp = head;
            head = head->next;
            delete temp;
        }
    }
    // Add a new version to the list
    void add_version(const std::string& content) {
        version_count++;
        Version_node* newNode = new Version_node(version_count, content);
        if (!head) {
            head = tail = newNode;
        }
        else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }
    // Rollback to a specific version
    void rollback_to_version(int versionNumber) {
        Version_node* current = tail;
        while (current && current->version_No != versionNumber) {
            Version_node* temp = current;
            current = current->prev;
            delete temp; // Delete newer versions
        }
        if (current) {
            current->next = nullptr;
            tail = current;
            version_count = versionNumber;
        }
        else {
            cout << "Version " << versionNumber << " not found.\n";
        }
    }
    // Display the version history
    void display_history() const {
        Version_node* current = head;
        while (current) {
            cout << "Version " << current->version_No << ": " << current->content << "\n";
            current = current->next;
        }
    }
    // Get the content of the most recent version
    string get_Current_Version_Content() const {
        return tail ? tail->content : "No versions available.";
    }
};
