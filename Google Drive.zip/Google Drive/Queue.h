#pragma once
#include "Stack.h" 
#include<iostream>

using namespace std;

struct Qnode {
    File_Metadata* file; 
    Qnode* next;   

    Qnode(File_Metadata* file) : file(file), next(nullptr) {}
};

class Queue {
private:
    Qnode* front;
    Qnode* rear;  
    int size;         
    int capacity;  

public:
    Queue(int capacity) : front(nullptr), rear(nullptr), size(0), capacity(capacity) {}
    ~Queue() {
        while (front) {
            Qnode* temp = front;
            front = front->next;
            delete temp->file; 
            delete temp;     
        }
    }
    // Add a file to the queue
    void enQ(File_Metadata* file) {
        cout << "Enqueuing file: " << file->name << endl; 
        // If the queue is full, remove the oldest file
        if (size == capacity) {
            cout << "Queue is full. Dequeuing oldest file." << endl;
            deq();
        }
        Qnode* newNode = new Qnode(file);
        if (!rear) {
            front = rear = newNode;
        }
        else {
            rear->next = newNode;
            rear = newNode;
        }
        size++;
    }
    // Remove the oldest file from the queue
    void deq() {
        if (!front) {
            return;
        }

        Qnode* temp = front;
        front = front->next;
        if (!front) rear = nullptr; 
        delete temp->file;          
        delete temp;              
        size--;
    }
    // Display the contents of the queue
    void display() const {
        Qnode* current = front;
        if (!current) {
            cout << "Queue is empty." << endl;
            return;
        }
        while (current) {
            cout << "File: " << current->file->name << ", Type: " << current->file->type << endl;
            current = current->next;
        }
    }
    // Check if the queue is empty
    bool isEmpty() const {
        return size == 0;
    }
};
