#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <ctime>
#include <queue>
#include <stack>
#include "HashTable.h"
#include "DoublyLinkedLIst.h"

using namespace std;

class Graph {
private:
    struct User_node {
        // User's basic info
        string user_name;
        string password;
        string security_Q;
        string security_Ans;
        string last_login_time;
        string last_logout_time;

        // Keeps version history of shared files
        Doubly_linkedlist shared_files;

        // List of users this user shared files with (one directional)
        vector<User_node*> shared_with;

        // Linked list structure (not directly used but declared)
        struct SharedWithNode {
            User_node* user;
            SharedWithNode* next;
            SharedWithNode(User_node* user) : user(user), next(nullptr) {}
        };

        SharedWithNode* shared_with_head;
        User_node* next;

        User_node(const string& name, const string& pass = "", const string& question = "", const string& answer = "")
            : user_name(name), password(pass), security_Q(question), security_Ans(answer), shared_with_head(nullptr), next(nullptr) {
        }
    };

    // Hash table of users (chained hashing)
    User_node** table;
    int tab_size;
    const string user_file = "users.txt";

    // Hash function for user names
    int hashfunc(const string& key) const {
        int hash = 0;
        for (char ch : key) {
            hash = (hash * 31 + ch) % tab_size;
        }
        return hash;
    }

    // Get readable current time for login/logout
    string get_current_time() const {
        time_t now = time(nullptr);
        char buffer[26];
        ctime_s(buffer, sizeof(buffer), &now);
        return string(buffer);
    }

    // Save user info to file (used during sign-up)
    void save_user_to_file(const User_node* user) const {
        ofstream outFile(user_file, ios::app);
        if (outFile.is_open()) {
            outFile << user->user_name << ","
                << user->password << ","
                << user->security_Q << ","
                << user->security_Ans << "\n";
            outFile.close();
        }
        else {
            cerr << "Error: Unable to open file for writing.\n";
        }
    }

    // Load users from file at the start of the program
    void load_users_from_file() {
        ifstream inFile(user_file);
        if (inFile.is_open()) {
            string line;
            while (getline(inFile, line)) {
                size_t pos1 = line.find(',');
                size_t pos2 = line.find(',', pos1 + 1);
                size_t pos3 = line.find(',', pos2 + 1);

                if (pos1 != string::npos && pos2 != string::npos && pos3 != string::npos) {
                    string userName = line.substr(0, pos1);
                    string password = line.substr(pos1 + 1, pos2 - pos1 - 1);
                    string question = line.substr(pos2 + 1, pos3 - pos2 - 1);
                    string answer = line.substr(pos3 + 1);

                    add_user(userName, password, question, answer);
                }
            }
            inFile.close();
        }
        else {
            cerr << "Error: Unable to open file for reading.\n";
        }
    }

    // Used to check if a user has been visited in BFS/DFS (manual visited array)
    bool is_visited(string visited[], int size, const string& name) const {
        for (int i = 0; i < size; i++) {
            if (visited[i] == name) return true;
        }
        return false;
    }

public:
    // Constructor - initializes hash table and loads users
    Graph(int size = 10) : tab_size(size) {
        table = new User_node * [tab_size];
        for (int i = 0; i < tab_size; ++i) {
            table[i] = nullptr;
        }
        load_users_from_file();
    }

    // Destructor - cleans up dynamically allocated memory
    ~Graph() {
        for (int i = 0; i < tab_size; ++i) {
            User_node* current = table[i];
            while (current) {
                User_node* temp = current;
                current = current->next;
                delete temp;
            }
        }
        delete[] table;
    }

    // Find user in the hash table by name
    User_node* find_user(const string& user) const {
        int index = hashfunc(user);
        User_node* current = table[index];
        while (current) {
            if (current->user_name == user) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }

    // Add new user to the hash table
    void add_user(const string& user, const string& pass = "", const string& question = "", const string& answer = "") {
        if (find_user(user)) return;
        int index = hashfunc(user);
        User_node* newUser = new User_node(user, pass, question, answer);
        newUser->next = table[index];
        table[index] = newUser;
    }

    // Sign up logic with file save
    void signUp(const string& user, const string& pass, const string& question, const string& answer) {
        if (find_user(user)) {
            cout << "User already exists!\n";
            return;
        }
        add_user(user, pass, question, answer);
        save_user_to_file(find_user(user));
        cout << "User signed up successfully!\n";
    }

    // Log in by matching credentials
    void logIn(const string& user, const string& pass) {
        User_node* user_node = find_user(user);
        if (!user_node) {
            cout << "User not found!\n";
            return;
        }
        if (user_node->password != pass) {
            cout << "Incorrect password!\n";
            return;
        }
        user_node->last_login_time = get_current_time();
        cout << "User logged in successfully at " << user_node->last_login_time;
    }

    // Log out user and update logout time
    void logOut(const string& user) {
        User_node* user_Node = find_user(user);
        if (!user_Node) {
            cout << "User not found!\n";
            return;
        }
        user_Node->last_logout_time = get_current_time();
        cout << "User logged out successfully at " << user_Node->last_logout_time;
    }

    // Recover password using security question
    void recover_password(const string& user, const string& answer) {
        User_node* userNode = find_user(user);
        if (!userNode) {
            cout << "User not found!\n";
            return;
        }
        if (userNode->security_Ans != answer) {
            cout << "Incorrect answer to the security question!\n";
            return;
        }
        cout << "Your password is: " << userNode->password << "\n";
    }

    // Share file by linking another user and saving version
    void share_file(const string& fromUser, const string& toUser, const string& fileName) {
        User_node* from_node = find_user(fromUser);
        User_node* to_node = find_user(toUser);
        if (!from_node || !to_node) {
            cout << "One or both users not found!\n";
            return;
        }
        from_node->shared_files.add_version(fileName);
        from_node->shared_with.push_back(to_node);
        cout << "File '" << fileName << "' shared from " << fromUser << " to " << toUser << ".\n";
    }

    // Display all shared files of a specific user
    void view_shared_files(const string& user) const {
        User_node* userNode = find_user(user);
        if (!userNode || userNode->shared_files.get_Current_Version_Content().empty()) {
            cout << "No files shared by " << user << ".\n";
            return;
        }
        cout << "Files shared by " << user << ":\n";
        userNode->shared_files.display_history();
    }

    // Traverse shared users using Breadth-First Search (for file sharing tracking)
    void BFS(const string& startUser, const string& fileName) {
        User_node* start_node = find_user(startUser);
        if (!start_node) {
            cout << "User not found!\n";
            return;
        }
        queue<User_node*> q;
        string visited[100];
        int visited_count = 0;
        q.push(start_node);
        visited[visited_count++] = start_node->user_name;
        cout << "BFS Traversal for file '" << fileName << "':\n";
        while (!q.empty()) {
            User_node* current = q.front();
            q.pop();
            if (current->shared_files.get_Current_Version_Content() == fileName) {
                cout << current->user_name << " has access to the file.\n";
            }
            for (User_node* neighbor : current->shared_with) {
                if (!is_visited(visited, visited_count, neighbor->user_name)) {
                    q.push(neighbor);
                    visited[visited_count++] = neighbor->user_name;
                }
            }
        }
    }

    // Traverse shared users using Depth-First Search
    void DFS(const string& startUser, const string& fileName) {
        User_node* start_node = find_user(startUser);
        if (!start_node) {
            cout << "User not found!\n";
            return;
        }
        stack<User_node*> s;
        string visited[100];
        int visited_count = 0;
        s.push(start_node);
        visited[visited_count++] = start_node->user_name;
        cout << "DFS Traversal for file '" << fileName << "':\n";
        while (!s.empty()) {
            User_node* current = s.top();
            s.pop();
            if (current->shared_files.get_Current_Version_Content() == fileName) {
                cout << current->user_name << " has access to the file.\n";
            }
            for (User_node* neighbor : current->shared_with) {
                if (!is_visited(visited, visited_count, neighbor->user_name)) {
                    s.push(neighbor);
                    visited[visited_count++] = neighbor->user_name;
                }
            }
        }
    }

    // Show each user and the files they shared
    void display_connections() const {
        cout << "User Connections and Shared Files:\n";
        for (int i = 0; i < tab_size; ++i) {
            User_node* current = table[i];
            while (current) {
                cout << current->user_name << ":\n";
                current->shared_files.display_history();
                current = current->next;
            }
        }
    }

    // Show login/logout records of each user
    void display_users() const {
        for (int i = 0; i < tab_size; ++i) {
            User_node* current = table[i];
            while (current) {
                cout << "User: " << current->user_name << "\n";
                cout << "Last Login: " << (current->last_login_time.empty() ? "Never" : current->last_login_time);
                cout << "Last Logout: " << (current->last_logout_time.empty() ? "Never" : current->last_logout_time);
                current = current->next;
            }
        }
    }
};
