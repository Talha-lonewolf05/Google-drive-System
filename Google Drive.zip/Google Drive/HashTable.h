﻿#pragma once
#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <string>
#include "DoublyLinkedLIst.h"

#define TABLE_SIZE 10

using namespace std;

struct File_Metadata {
    string name;
    string type;
    int size;
    string date;
    string owner;
    string parent_folder; // New field to store the parent folder
    File_Metadata* next;
    Doubly_linkedlist version_history; // Add version history

    File_Metadata(string name, string type, int size, string date, string owner, string parentFolder)
        : name(name), type(type), size(size), date(date), owner(owner), parent_folder(parentFolder), next(nullptr) {
    }

    File_Metadata(string name, string type, int size, string date, string owner);
};

int hashfunc(const string& key, int tableSize);

class Hash_table {
private:
    File_Metadata** table; 
    int capacity;

public:
    Hash_table(); 
    ~Hash_table(); 

    void insert(const string& name, const string& type,
        int size, const string& date, const string& owner);

    File_Metadata* search(const string& name);

    void remove(const string& name);
};

#endif
